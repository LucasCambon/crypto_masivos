import { addLoginRegisterEventHandlers } from '../features/auth/auth-handlers.js';

document.addEventListener('DOMContentLoaded', addLoginRegisterEventHandlers);
