import { createCurrencyCard } from '../../utils/currency-helpers.js';

export function createCurrency(currency) {
	return createCurrencyCard(currency);
}
